package P03PlayersAndMonsters.Knights;

import P03PlayersAndMonsters.Hero;

public class Knight extends Hero {

    public Knight(String username, int level) {
        super(username, level);
    }

}
