package P03PlayersAndMonsters.Knights;

public class BladeKnight extends DarkKnight {

    public BladeKnight(String username, int level) {
        super(username, level);
    }

}
