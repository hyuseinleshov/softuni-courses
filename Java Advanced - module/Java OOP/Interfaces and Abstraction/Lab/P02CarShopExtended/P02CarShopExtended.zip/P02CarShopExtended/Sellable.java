package P02CarShopExtended;

public interface Sellable {

    Double getPrice();

}
