package P02MultipleImplementation;

public interface Person {

    String getName();

    int getAge();

}
