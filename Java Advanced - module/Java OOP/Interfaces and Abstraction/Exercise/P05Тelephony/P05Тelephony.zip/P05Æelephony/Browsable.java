package P05Тelephony;

public interface Browsable {

    String browse();

}
