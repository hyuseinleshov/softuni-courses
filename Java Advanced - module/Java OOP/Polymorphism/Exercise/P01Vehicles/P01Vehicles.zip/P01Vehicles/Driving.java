package P01Vehicles;

public interface Driving {

    boolean drive(double km);

}
