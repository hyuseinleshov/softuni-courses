package P01Vehicles;

public interface Refueling {

    void refuel(double litres);

}
