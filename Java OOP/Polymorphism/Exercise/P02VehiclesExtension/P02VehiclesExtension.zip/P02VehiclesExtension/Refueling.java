package P02VehiclesExtension;

public interface Refueling {

    void refuel(double litres);

}
