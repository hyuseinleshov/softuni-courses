package P02VehiclesExtension;

public interface Driving {

    boolean drive(double km);

}
