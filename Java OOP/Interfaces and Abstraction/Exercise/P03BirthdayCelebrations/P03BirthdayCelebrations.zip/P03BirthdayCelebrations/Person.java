package P03BirthdayCelebrations;

public interface Person {

    String getName();

    int getAge();

}
