package P03BirthdayCelebrations;

public interface Birthable {

    String getBirthDate();

}
