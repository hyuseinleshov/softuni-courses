package Exercises.P02CompanyRoster;

public class Department {

    private Employee employee;

    public Department(Employee employee) {
        this.employee = employee;
    }

}
