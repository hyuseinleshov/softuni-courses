package Exercises.P05CarSalesman;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        Map<String, Engine> engines = new LinkedHashMap<>();
        Map<String, Car> cars = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {

            String[] tokens = scanner.nextLine().split("\\s+");

            String model = tokens[0];
            int power = Integer.parseInt(tokens[1]);

            int length = tokens.length;

            Engine engine = null;

            if (length == 2) {
                engine = new Engine(model, power);
            } else if (length == 3) {
                try {
                    int displacement = Integer.parseInt(tokens[2]);
                    engine = new Engine(model, power, displacement);
                } catch (NumberFormatException e) {
                    String efficiency = tokens[2];
                    engine = new Engine(model, power, efficiency);
                }
            } else if (length == 4) {

                int displacement = Integer.parseInt(tokens[2]);;
                String efficiency = tokens[3];

                engine = new Engine(model, power, displacement, efficiency);
            }

            engines.put(model, engine);

        }

        int m = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < m; i++) {

            String[] tokens = scanner.nextLine().split("\\s+");

            String model = tokens[0];
            String engineModel = tokens[1];

            Engine engine = engines.get(engineModel);

            Car car = null;

            int length = tokens.length;

            if (length == 2) {
                car = new Car(model, engine);
            } else if (length == 3) {
                try {
                    int weight = Integer.parseInt(tokens[2]);
                    car = new Car(model, engine, weight);
                } catch (NumberFormatException e) {
                    String color = tokens[2];
                    car = new Car(model, engine, color);
                }
            } else if (length == 4) {

                int weight = Integer.parseInt(tokens[2]);
                String color = tokens[3];

                car = new Car(model, engine, weight, color);
            }

            cars.put(model, car);

        }

        for (Map.Entry<String, Car> car : cars.entrySet()) {

            System.out.println(car.getKey() + ":");

            Car currentCar = car.getValue();
            Engine currentEngine = currentCar.getEngine();

            System.out.println(currentEngine.getModel() + ":");

            System.out.println("Power: " + currentEngine.getPower());

            if (currentEngine.getDisplacement() == -1) {
                System.out.println("Displacement: n/a");
            } else {
                System.out.println("Displacement: " + currentEngine.getDisplacement());
            }

            System.out.println("Efficiency: " + currentEngine.getEfficiency());

            if (currentCar.getWeight() == -1) {
                System.out.println("Weight: n/a");
            } else {
                System.out.println("Weight: " + currentCar.getWeight());
            }

            System.out.println("Color: " + currentCar.getColor());

        }

    }

}
