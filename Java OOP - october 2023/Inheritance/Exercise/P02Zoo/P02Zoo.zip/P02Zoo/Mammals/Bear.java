package Exercise.P02Zoo.Mammals;

public class Bear extends Mammal {

    public Bear(String name) {
        super(name);
    }

}
