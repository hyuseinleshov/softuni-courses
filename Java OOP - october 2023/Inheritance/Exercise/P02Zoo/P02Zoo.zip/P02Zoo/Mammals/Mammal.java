package Exercise.P02Zoo.Mammals;

import Exercise.P02Zoo.Animal;

public class Mammal extends Animal {

    public Mammal(String name) {
        super(name);
    }

}
