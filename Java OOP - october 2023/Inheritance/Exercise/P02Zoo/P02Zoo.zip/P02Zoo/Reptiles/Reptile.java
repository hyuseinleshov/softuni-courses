package Exercise.P02Zoo.Reptiles;

import Exercise.P02Zoo.Animal;

public class Reptile extends Animal {

    public Reptile(String name) {
        super(name);
    }

}
