package Exercise.P02Zoo.Reptiles;

public class Snake extends Reptile {

    public Snake(String name) {
        super(name);
    }

}
