package Exercise.P02Zoo.Reptiles;

public class Lizard extends Reptile {

    public Lizard(String name) {
        super(name);
    }

}
