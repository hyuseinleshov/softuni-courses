package P03RandomArrayList;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        RandomArrayList<Integer> randomArrayList = new RandomArrayList();

        randomArrayList.add(3);
        randomArrayList.add(5);
        randomArrayList.add(7);

        System.out.println(randomArrayList.getRandomElement());

    }

}
