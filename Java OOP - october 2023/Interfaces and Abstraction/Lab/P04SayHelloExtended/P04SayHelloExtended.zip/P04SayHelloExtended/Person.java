package P04SayHelloExtended;

public interface Person {

    String getName();
    String sayHello();

}
